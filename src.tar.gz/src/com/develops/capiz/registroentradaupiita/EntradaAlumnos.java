package com.develops.capiz.registroentradaupiita;

import java.util.LinkedList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class EntradaAlumnos extends SQLiteOpenHelper {

	public EntradaAlumnos(Context context) {
		super(context, "EntradaAlumnos", null, 1);
	}

	@Override
	public void onCreate(SQLiteDatabase dataBase) {
		// TODO Apéndice de método generado automáticamente
		dataBase.execSQL("create table Entradas(Boleta TEXT PRIMARY KEY,Nombre TEXT,Asunto TEXT,Observaciones TEXT,Escuela TEXT,Entrada NUMERIC, Salida NUMERIC)");
		dataBase.execSQL("create table Macho(Boleta TEXT PRIMARY KEY,Nombre TEXT,Password TEXT)");
		ContentValues values = new ContentValues();
		values.put("Boleta", "2011640347");
		values.put("Nombre", "Capiz");
		values.put("Password", "upiita_rules_123");
		dataBase.insert("Macho", "---", values);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Apéndice de método generado automáticamente

	}

	public void insertaRegistroEntrada(String Boleta, String[] datos,
			Long horaRegistro) {
		try {
			SQLiteDatabase db = getWritableDatabase();
			ContentValues values = new ContentValues();
			values.put("Boleta", Boleta);
			values.put("Nombre", datos[0]);
			values.put("Asunto", datos[1]);
			values.put("Observaciones", datos[2]);
			values.put("Escuela", datos[3]);
			values.put("Entrada", horaRegistro);
			db.insert("Entradas", "---", values);
		} catch (NullPointerException | ArrayIndexOutOfBoundsException e) {

		}
	}
	
	public LinkedList<String> consultaMacho(String[] columns, String selection, String[] selVals){
		LinkedList<String> results = new LinkedList<String>();
		SQLiteDatabase db = getReadableDatabase();
		Cursor cursor = db.query("macho", columns, selection, selVals, null, null, null, null);
		while( cursor.moveToNext() ){
			String aux = new String();
			for(int i=0 ; i<cursor.getColumnCount(); i++){
				aux = aux.concat(cursor.getString(i)+" \\_");
			}			
			results.add(aux);
		}
		db.close();
		return results;
	}

	public boolean insertaRegistroMacho(String datos[]) {
			SQLiteDatabase db = getWritableDatabase();
			ContentValues values = new ContentValues();
			values.put("Boleta",datos[0]);
			values.put("Nombre", datos[1]);
			values.put("Password",datos[2]);
			if( db.insert("Macho", "---", values) == -1){
				db.close();
				return false;
			}else{
				db.close();
				return true;
			}
	}
	
	public LinkedList<String> consultaBoleta(String Boleta) {
		LinkedList<String> results = new LinkedList<String>();
		SQLiteDatabase db = getReadableDatabase();
		String[] aux = { Boleta.toString() };
		Cursor cursor = db.query("Entradas", null, "Boleta", aux, null, null,
				null, null);
		if (cursor.getCount() > 1) {
			results.add("La boleta estuvo dos veces");
		}
		while (cursor.moveToNext()) {
			try {
				results.add(cursor.getInt(0) + "\n" + cursor.getString(1)
						+ "\n" + cursor.getString(2) + "\n"
						+ cursor.getString(3) + "\n" + cursor.getString(4)
						+ "\n" + cursor.getString(5) + "\n"
						+ cursor.getString(6));
			} catch (Exception e) {
				results.add("ERROR\n" + e.toString());
			}
		}
		db.close();
		return results;
	}

}
