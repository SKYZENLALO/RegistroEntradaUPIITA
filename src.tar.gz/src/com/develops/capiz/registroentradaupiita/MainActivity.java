package com.develops.capiz.registroentradaupiita;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private EditText input1;
	private EditText input2;

	// private EntradaAlumnos entradaUPIITA_bd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		try { 
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_main);
			TextView background = (TextView) findViewById(R.id.bkgd);
			background.setTextColor(Color.WHITE);// 0x00c5ffff);
			background.requestFocus();
			RelativeLayout container = (RelativeLayout) findViewById(R.id.panel);
			container.setBackgroundColor(Color.argb(248, 84, 3, 4));
			input1 = (EditText) findViewById(R.id.input_box1);
			input2 = (EditText) findViewById(R.id.input_box2);
			Button go = (Button) findViewById(R.id.go);
			Button registro = (Button) findViewById(R.id.registro);
			go.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					validaUsuario();
				}
			});
			registro.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					launchValidaRegistro();
				}
			});
			// entradaUPIITA_bd = new EntradaAlumnos(this);
		} catch (Exception e) {
			Intent i = new Intent(this, Mensaje.class);
			i.putExtra("msj", e.toString());
			startActivity(i);
		}
	}

	public void validaUsuario() {
		String[] datos = { "Boleta", "Nombre" };
		String[] vals = { input1.getText().toString(),
				input2.getText().toString() };
		EntradaAlumnos entradaUPIITA_bd = new EntradaAlumnos(this);
		if (entradaUPIITA_bd.consultaMacho(datos, "Boleta=?,Nombre=?", vals)
				.size() != 1) {
			Toast.makeText(this, "El usuario no existe", Toast.LENGTH_SHORT)
					.show();
		} else {
			launchQueryWindow();
		}
	}

	public void launchValidaRegistro() {
		Intent i = new Intent(this, ValidaRegistro.class);
		startActivity(i);
	}

	public void launchQueryWindow() {

	}
}
