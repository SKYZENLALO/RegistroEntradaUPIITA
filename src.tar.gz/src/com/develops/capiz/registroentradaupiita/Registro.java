package com.develops.capiz.registroentradaupiita;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Registro extends Activity {

	private TextView errorMessage;
	private EditText EditText1;
	private EditText EditText2;
	private EditText EditText3;
	private EditText EditText4;
	private RelativeLayout container0;
	private RelativeLayout container1;
	private RelativeLayout container2;
	private RelativeLayout container3;
	private Button go2;
	private EntradaAlumnos entradaAlumnosUPIITA;
	
	@Override
	protected void onCreate(Bundle b){
		super.onCreate(b);
		setContentView(R.layout.elemento_nuevo);
		RelativeLayout container = (RelativeLayout)findViewById(R.id.header3);
		container.setBackgroundColor(Color.argb(248, 84, 3, 4));
		TextView background = (TextView)findViewById(R.id.background3);
		background.setTextColor(Color.WHITE);//0x00c5fff8);
		errorMessage = (TextView)findViewById(R.id.error_message);
		errorMessage.setTextColor(Color.RED);
		EditText1 = (EditText)findViewById(R.id.input_name_register1);
		EditText2= (EditText)findViewById(R.id.input_boleta_register1);
		EditText3 = (EditText)findViewById(R.id.input_psswd_register1);
		EditText4 = (EditText)findViewById(R.id.input_psswd_register2);
		container0 = (RelativeLayout)findViewById(R.id.container);
		container1 = (RelativeLayout)findViewById(R.id.container1);
		container2 = (RelativeLayout)findViewById(R.id.container2);
		container3 = (RelativeLayout)findViewById(R.id.container3);
		go2 = (Button)findViewById(R.id.go2);
		entradaAlumnosUPIITA = new EntradaAlumnos(this);
		go2.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				String[] datos = {EditText1.getText().toString(),
								  EditText2.getText().toString(),
								  EditText3.getText().toString(),
								  EditText4.getText().toString()};
				if( datos[0].length() == 0){
					errorMessage.setText("Debe escribir un nombre de usuario.");
					container0.setVisibility(View.VISIBLE);
				}
				if( datos[1].length() != 10 ){
					errorMessage.setText("La boleta debe ser de 10 caracteres.");
					container1.setVisibility(View.VISIBLE);
				}
				if( datos[2].equals(datos[3]) ){
					if( datos[2].length() > 5 ){
						insertarValoresMacho(datos);
					}else{
						errorMessage.setText("Debes escribir una contraseña con más de 5 caracteres.");
						container2.setVisibility(View.VISIBLE);
						container3.setVisibility(View.VISIBLE);
						EditText3.setText("");
						EditText4.setText("");
					}
				}else{
					errorMessage.setText("Las contraseñas no coinciden.");
					EditText4.setText("");
					Toast.makeText(Registro.this,"Valores incorrectos",Toast.LENGTH_LONG).show();
				}
			}
		});
	}
	public void insertarValoresMacho(String[] datos){
		if(entradaAlumnosUPIITA.insertaRegistroMacho(datos)){
			Toast.makeText(this, "Correcto, usuario registrado", Toast.LENGTH_SHORT).show();
			limpiarPantalla();
		}else{
			Toast.makeText(this, "El usuario ya existe", Toast.LENGTH_SHORT).show();
			EditText3.setText("");
			EditText4.setText("");
		}
	}
	private void limpiarPantalla(){
		EditText1.setText("");
		EditText2.setText("");
		EditText3.setText("");
		EditText4.setText("");
		errorMessage.setText("");
		container0.setVisibility(View.INVISIBLE);
		container1.setVisibility(View.INVISIBLE);
		container2.setVisibility(View.INVISIBLE);
		container3.setVisibility(View.INVISIBLE);
	}
}
