package com.develops.capiz.registroentradaupiita;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class GuardianManager extends Activity {

	private Button btn1;
	private Button btn2;
	@Override
	protected void onCreate(Bundle b){
		try{
		super.onCreate(b);
		setContentView(R.layout.guardians_manager);
		btn1 = (Button)findViewById(R.id.leftButton_guards_manager);
		btn2 = (Button)findViewById(R.id.rightButton_guards_manager);
		TextView mainHeader = (TextView)findViewById(R.id.bkgd_guards_manager);
		RelativeLayout container = (RelativeLayout)findViewById(R.id.panel_guards_manager);
		container.setBackgroundColor(Color.argb(248, 84, 3, 4));
		mainHeader.setTextColor(Color.WHITE);
		btn2.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				launchAdminList();
			}
		});
		btn1.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				launchRegistro();
			}
		});
		}catch(Exception e){
			Intent i = new Intent(this,Mensaje.class);
			i.putExtra("msj", e.toString());
			startActivity(i);
		}
	}
	private void launchAdminList(){
		Intent i = new Intent(this,Admins.class);
		startActivity(i);
	}
	private void launchRegistro(){
		Intent i = new Intent(this,Registro.class);
		startActivity(i);
	}
}
