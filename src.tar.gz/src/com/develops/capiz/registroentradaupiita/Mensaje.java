package com.develops.capiz.registroentradaupiita;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Mensaje extends Activity {

	private String msj;
	@Override
	protected void onCreate(Bundle b){
		super.onCreate(b);
		setContentView(R.layout.mensaje);
		if( b == null ){
			Bundle ex = getIntent().getExtras();
			msj = ex.getString("msj");
		}else{
			msj = b.getString("msj");
		}
		TextView text = (TextView)findViewById(R.id.texto);
		text.setText(msj);
	}
	@Override
	protected void onSaveInstanceState(Bundle b){
		super.onSaveInstanceState(b);
		b.putString("msj", msj);
	}
	@Override
	protected void onRestoreInstanceState(Bundle b){
		super.onRestoreInstanceState(b);
		msj = b.getString("msj");
	}
}
