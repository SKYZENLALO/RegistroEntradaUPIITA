package com.develops.capiz.registroentradaupiita;

public class Guardian {

	private String boleta;
	private String nombre;

	public String getBoleta() {
		return boleta;
	}

	public String getNombre() {
		return nombre;
	}

	public void setBoleta(String boleta) {
		this.boleta = boleta;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
}
